import tkinter as tk
from tkinter import *
from tkinter import filedialog
import os
import tkinter as tk
from PIL import Image
from PIL import ImageTk
import face_recognition as fr
import os
import cv2
import face_recognition
import numpy as np
from time import sleep
import csv

root=tk.Tk()

root.geometry("400x150")


def func():


 def get_encoded_faces():
  
    encoded = {}

    for dirpath, dnames, fnames in os.walk("./faces"):
        for f in fnames:
            if f.endswith(".jpg") or f.endswith(".png"):
                face = fr.load_image_file("faces/" + f)
                encoding = fr.face_encodings(face)[0]
                encoded[f.split(".")[0]] = encoding

    return encoded


 def unknown_image_encoded(img):
  
    face = fr.load_image_file("faces/" + img)
    encoding = fr.face_encodings(face)[0]

    return encoding


 def classify_face(im):
    
    faces = get_encoded_faces()
    faces_encoded = list(faces.values())
    known_face_names = list(faces.keys())

    img = cv2.imread(im, 1)
    #img = cv2.resize(img, (0, 0), fx=0.5, fy=0.5)
    #img = img[:,:,::-1]
 
    face_locations = face_recognition.face_locations(img)
    unknown_face_encodings = face_recognition.face_encodings(img, face_locations)

    face_names = []
    for face_encoding in unknown_face_encodings:
       
        matches = face_recognition.compare_faces(faces_encoded, face_encoding)
        name = "Unknown"

        
        face_distances = face_recognition.face_distance(faces_encoded, face_encoding)
        best_match_index = np.argmin(face_distances)
        if matches[best_match_index]:
            name = known_face_names[best_match_index]
	


        face_names.append(name)

        for (top, right, bottom, left), name in zip(face_locations, face_names):
            
            cv2.rectangle(img, (left-20, top-20), (right+20, bottom+20), (255, 0, 0), 2)

            
            cv2.rectangle(img, (left-20, bottom -15), (right+20, bottom+20), (255, 0, 0), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(img, name, (left -20, bottom + 15), font, 1.0, (255, 255, 255), 2)


   
    while True:

        cv2.imshow('Video', img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            return face_names 
 print(classify_face("test.jpg"))
 num=int(input('No. of records to be displayed: '))
 for i in range(num):
  name=input('Enter Name:\n')
  src=input()
  if src=='info':
	## Choosing the Details of the Dataset
 	 csv_file=csv.reader(open('D:/final pro/final_rec/Book.csv','r'))
 	 for row in csv_file:
 		 if name in row[0]:
 			 print(row)
  else:
 	 print('No records')
	


def show():
	fln=filedialog.askopenfilename(initialdir=os.getcwd(),title="Select Image File",filetypes=(("JPG File","*.jpg"),("PNG file","*png"),("All Files","*.*")))
	img=Image.open(fln)
	img.thumbnail((850,850))
	img=ImageTk.PhotoImage(img)
	lbl.configure(image=img)
	lbl.image=img



frm=Frame(root)
frm.pack(side=BOTTOM,padx=35,pady=35)

lbl=Label(root)
lbl.pack()

btn=tk.Button(root,text="Find Match",command=func)
btn.pack(side="bottom",padx=30,pady=30)

btn1=Button(frm,text="Browse Image",command=show)
btn1.pack(side=tk.LEFT,padx=30)


root.title("Advanced Reverse Image Search and Profile Creation")
root.mainloop()


