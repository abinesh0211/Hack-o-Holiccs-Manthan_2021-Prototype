import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from time import time
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from PIL import Image

df = pd.read_csv("face_data.csv")
targets = df["target"]

pixels = df.drop(["target"],axis=1)

img_pixels=(np.array('f2.jfif'))
img_arr = ['img_pixels']

x_train, x_test ,y_train ,y_test = train_test_split(pixels, targets,test_size=1)

pca = PCA(n_components=150).fit(x_train)


print("Projecting the input data on the eigenfaces orthonormal basis")
Xtrain_pca = pca.transform(x_train)

clf = SVC(kernel='rbf',C=1000,gamma=0.001)
clf = clf.fit(Xtrain_pca,y_train)

print("Predicting people's names on the test set")
t0 = time()
Xtest_pca = pca.transform(x_test)
y_pred = clf.predict(Xtest_pca)
print("done in %0.3fs" % (time() - t0))
result=np.array([classification_report(y_test, y_pred,output_dict=bool)])

cnt=0 

for i in result:
	for j in i.keys():
		if(cnt==0):
			cnt=cnt+1
			id = int(j)
	 